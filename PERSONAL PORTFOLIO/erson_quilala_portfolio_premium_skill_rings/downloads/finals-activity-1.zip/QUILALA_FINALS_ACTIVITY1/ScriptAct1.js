console.log("document")
const nickname = document.getElementById("nickname")
const name = document.getElementById("name")
const year = document.getElementById("year")
const message = document.getElementById("message")
const message1 = document.getElementById("message1")

const click = document.getElementById("click")
const double = document.getElementById("double")

click.addEventListener("click", function(){
    name.innerHTML = "Future Web Developer"
})

double.addEventListener("double", function(){
    double.style.backgroundColor = "Light Blue"
})
const hold = document.getElementById("hold")
const Image1 = document.getElementById("Img1")


const box1 = document.getElementById("box1")


box1.addEventListener("mouseover", function(){
    message.innerHTML = "You're inside the box"
})

box1.addEventListener("mouseout", function(){
    message.innerHTML = "You're outside the box"
})

nickname.addEventListener("focus", function (){
    message.innerHTML = "Input is Active"
    nickname.style.backgroundColor = "lightyellow"
})


nickname.addEventListener("blur", function (){
    nickname.style.backgroundColor = "white"
    message.innerHTML = "Welcome Back!"
    
})

nickname.addEventListener("input", function(){
    message.innerHTML = "Future Web Developer"
    name.innerHTML = nickname.value
})

year.addEventListener("change", function(){
    message.innerHTML = "year.value"
})

click.addEventListener("click", function(){
    message.innerHTML = "Click Detected!"

})

double.addEventListener("double", function(){
    message.innerHTML = "Double Clicked Detected!"
})

Image1.addEventListener("mouseover", function(){
    message.innerHTML = " Your mouse is over the image!"
    Image1.style.transform = "scale(1.2,1.2)"
})

Image1.addEventListener("mouseout", function(){
    message.innerHTML = " Your mouse is over the image!"
    Image1.style.transform = "scale(1)"
})


hold.addEventListener("mousedown", function(){
    message.innerHTML = "You have the Force"
})

hold.addEventListener("mouseup", function(){
    message.innerHTML = "Welcome Back!"
})