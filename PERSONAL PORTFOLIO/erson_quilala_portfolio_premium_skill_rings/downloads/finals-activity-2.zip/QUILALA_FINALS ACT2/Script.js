const Message = document.getElementById("message")
const Button1 = document.getElementById("loadBtn")
const Profile = document.getElementById("profile")
const Grades = document.getElementById("grades")
const Schedule = document.getElementById("schedule")


Button1.addEventListener("click", function(){
    Message.innerHTML = "Loading Dashboard..."

    Profile.innerHTML = "Profile: Waiting..."
    Grades.innerHTML = "Grades: Waiting..."
    Schedule.innerHTML = "Schedule: Waiting..."



    const profilePromise = new Promise(function(resolve){
        setTimeout(function(){
            Profile.innerHTML = "Profile: Loaded!"
            resolve()
        },1000)
    })
    

    const gradesPromise = new Promise(function(resolve){
        setTimeout(function(){
            Grades.innerHTML = "Grades: Loaded!"
            resolve()
        },2000)
    })


    const schedulePromise = new Promise(function(resolve){
        setTimeout(function(){
            Schedule.innerHTML = "Schedule: Loaded!"
            resolve()
        },3000)
    })


    Promise.all([profilePromise, gradesPromise, schedulePromise])

    .then(function(){
        setTimeout(function(){
        Message.innerHTML = "Dashboard Ready!"
        },2000)

    })

})