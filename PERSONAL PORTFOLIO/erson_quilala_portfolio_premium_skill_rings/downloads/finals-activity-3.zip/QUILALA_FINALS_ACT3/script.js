$("#title").text("Welcome BSCS!")

$(document).ready(function(){

    $("#title").text("Good Morning")

    $("p.intro").css("color", "pink")

    $("*").css("background", "Light gray")

    $(".btn2").click(function(){

        //$(this).css("background", "black")

    })

    $("[href]").css("color", "red")
    $("ul li:first-child").css("color", "purple")

    $("tr:even").css("background", "lightblue")

    $("tr:odd").css("background", "lightgreen")

    $("th").css("background", "pink")

    $("#btn").click(function(){
        $("#message").text("You Clicked the Button!")
    })

    $("#btn").dblclick(function(){
        $("#message").text("You Double Clicked the Button!")
    })

    $("#btn").mouseenter(function(){
        $("#message").text("You're Mouse reached the button!")
    })

    $("#btn").mouseleave(function(){
        $("#message").text("You leave your mouse!")
    })

    $("#btn").mousedown(function(){
        $(this).css("background", "green")
    })

     $("#btn").mouseup(function(){
        $(this).css("background", "red")
    })

    $("#name").focus(function(){
        $("#message").text("You Select the Text box!!")
        $(this).css("background", "lightyellow")
    })

    $("#name").blur(function(){
        $("#message").text("You leave the Text input!")
        $(this).css("background", "lightblue")
    })

    $("#course").change(function(){
        $("#message").text($(this).val())
    })

    $("#btn2").click(function(){
        $("#table").hide("slow")
    })

    $("#btn2").dblclick(function(){
        $("#table").show(2000)
    })


})
   



